// Add to imports in index.js:
import { ProtocolOverWSHandler, ProtocolOverXHTTPHandler } from './src/Core-function.js';

// Add these two routes in the fetch handler, BEFORE the 404 response:
// xhttp upload (POST) and download (GET) — path: /xhttp/{userID}/{sessionID}
if (url.pathname.startsWith(`/xhttp/${cfg.userID}`))
  return ProtocolOverXHTTPHandler(request, requestConfig);
