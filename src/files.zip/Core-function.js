import { connect } from "cloudflare:sockets";
import { safeFetch } from './VlessConfig.js'; 
import { CONST } from './settings.js';

// ─── Shared TextDecoder instance ───────────────────────────────────────────
const sharedTextDecoder = new TextDecoder();

// ─── Buffer concat helper (replaces Blob merging) ──────────────────────────
function concatBuffers(...buffers) {
  const total = buffers.reduce((n, b) => n + (b.byteLength ?? b.length ?? 0), 0);
  const result = new Uint8Array(total);
  let offset = 0;
  for (const b of buffers) {
    const view = b instanceof Uint8Array ? b : new Uint8Array(b.buffer ?? b);
    result.set(view, offset);
    offset += view.byteLength;
  }
  return result.buffer;
}

// ───────────────────────────────────────────────────────────────────────────
// WebSocket (ws) handler — existing VLESS over WebSocket
// ───────────────────────────────────────────────────────────────────────────
/**
 * Core vless protocol logic over WebSocket.
 * @param {Request} reqst
 * @param {object} config
 * @returns {Promise<Response>}
 */
export async function ProtocolOverWSHandler(reqst, config) {
  const wsPair = new WebSocketPair();
  const [client, webSocket] = Object.values(wsPair);
  webSocket.accept();
  let address = "";
  let portWithRandomLog = "";
  let udpStreamWriter = null;
  const log = (info, event) => {
    console.log(`[${address}:${portWithRandomLog}] ${info}`, event || "");
  };
  const earlyDataHeaderMain = reqst.headers.get("Sec-WebSocket-Protocol") || "";
  const readableWebSocketStream = MakeReadableWebSocketStream(webSocket, earlyDataHeaderMain, log);
  let remoteSocketWapper = { value: null };

  readableWebSocketStream
    .pipeTo(
      new WritableStream({
        async write(chunk, controller) {
          if (udpStreamWriter) {
            return udpStreamWriter.write(chunk);
          }
          if (remoteSocketWapper.value) {
            const writer = remoteSocketWapper.value.writable.getWriter();
            await writer.write(chunk);
            writer.releaseLock();
            return;
          }
          const buffer = chunk instanceof Blob ? await chunk.arrayBuffer() : chunk.buffer || chunk;
          const {
            hasError,
            message,
            addressType,
            portRemote = 443,
            addressRemote = "",
            rawDataIndex,
            ProtocolVersion = new Uint8Array([0, 0]),
            isUDP,
          } = ProcessProtocolHeader(buffer, config.userID);
          address = addressRemote;
          portWithRandomLog = `${portRemote}--${Math.random()} ${isUDP ? "udp" : "tcp"} `;

          if (hasError) throw new Error(message);

          const vlessResponseHeader = new Uint8Array([ProtocolVersion[0], 0]);
          const rawClientData = buffer.slice(rawDataIndex);

          if (isUDP) {
            if (portRemote === 53) {
              const dnsPipeline = await createDnsPipeline(webSocket, vlessResponseHeader, log);
              udpStreamWriter = dnsPipeline.write;
              udpStreamWriter(rawClientData);
            } else {
              throw new Error("UDP proxy is only enabled for DNS (port 53)");
            }
            return;
          }

          HandleTCPOutBound(
            remoteSocketWapper,
            addressType,
            addressRemote,
            portRemote,
            rawClientData,
            webSocket,
            vlessResponseHeader,
            log,
            config,
          );
        },
        close() {
          log(`readableWebSocketStream closed`);
        },
        abort(err) {
          log(`readableWebSocketStream aborted`, err);
        },
      }),
    )
    .catch((err) => {
      console.error("Pipeline failed:", err.stack || err);
    });

  return new Response(null, { status: 101, webSocket: client });
}

// ───────────────────────────────────────────────────────────────────────────
// xhttp (splithttp) handler — NEW
// xhttp sends VLESS data via chunked HTTP POST (upload) and GET (download)
// Much harder to detect than WebSocket — looks like normal HTTP traffic
// Only TLS supported (port 443 etc.)
// ───────────────────────────────────────────────────────────────────────────
/**
 * VLESS over xhttp (splithttp) transport handler.
 * Client sends data via POST /{path}/{sessionID}
 * Client receives data via GET /{path}/{sessionID}
 * @param {Request} reqst
 * @param {object} config
 * @returns {Promise<Response>}
 */
export async function ProtocolOverXHTTPHandler(reqst, config) {
  const url = new URL(reqst.url);
  const method = reqst.method;

  // xhttp uses a session ID in the URL path to correlate upload/download
  // e.g. /xhttp/abc123/SESSION_ID
  const sessionID = url.pathname.split("/").pop();

  // ── GET request: client wants to receive data (download stream) ──────────
  if (method === "GET") {
    const { readable, writable } = new TransformStream();
    const writer = writable.getWriter();

    // Store writer in global session map so POST handler can write to it
    xhttpSessions.set(sessionID, writer);

    // Clean up session after client disconnects
    reqst.signal?.addEventListener("abort", () => {
      xhttpSessions.delete(sessionID);
      writer.close().catch(() => {});
    });

    return new Response(readable, {
      status: 200,
      headers: {
        "Content-Type": "application/octet-stream",
        "Transfer-Encoding": "chunked",
        "X-Accel-Buffering": "no", // disable nginx buffering
        "Cache-Control": "no-store",
      },
    });
  }

  // ── POST request: client is sending data (upload) ─────────────────────
  if (method === "POST") {
    const log = (info) => console.log(`[xhttp:${sessionID}] ${info}`);

    // Read the full POST body as the VLESS payload
    const body = await reqst.arrayBuffer();
    if (!body || body.byteLength === 0) {
      return new Response("Empty body", { status: 400 });
    }

    const {
      hasError,
      message,
      addressType,
      portRemote = 443,
      addressRemote = "",
      rawDataIndex,
      ProtocolVersion = new Uint8Array([0, 0]),
      isUDP,
    } = ProcessProtocolHeader(body, config.userID);

    if (hasError) {
      log(`Header error: ${message}`);
      return new Response(message, { status: 400 });
    }

    if (isUDP && portRemote !== 53) {
      return new Response("UDP only allowed for DNS", { status: 400 });
    }

    const vlessResponseHeader = new Uint8Array([ProtocolVersion[0], 0]);
    const rawClientData = body.slice(rawDataIndex);

    // Get the download writer for this session (GET must arrive first)
    // Wait briefly if GET hasn't arrived yet
    let sessionWriter = xhttpSessions.get(sessionID);
    if (!sessionWriter) {
      await new Promise(r => setTimeout(r, 100));
      sessionWriter = xhttpSessions.get(sessionID);
    }

    if (!sessionWriter) {
      log(`No GET session found for ${sessionID}`);
      return new Response("Session not found", { status: 404 });
    }

    // ── DNS over UDP ───────────────────────────────────────────────────────
    if (isUDP) {
      try {
        const resp = await safeFetch(
          "https://1.1.1.1/dns-query",
          { method: "POST", headers: { "content-type": "application/dns-message" }, body: rawClientData },
          3000,
        );
        const dnsResult = await resp.arrayBuffer();
        const udpSize = dnsResult.byteLength;
        const udpSizeBuffer = new Uint8Array([(udpSize >> 8) & 0xff, udpSize & 0xff]);
        const response = concatBuffers(vlessResponseHeader, udpSizeBuffer, dnsResult);
        await sessionWriter.write(new Uint8Array(response));
      } catch (e) {
        log(`DNS error: ${e.message}`);
      }
      return new Response("ok", { status: 200 });
    }

    // ── TCP outbound ───────────────────────────────────────────────────────
    try {
      const tcpSocket = config.enableSocks
        ? await socks5Connect(addressType, addressRemote, portRemote, log, config.parsedSocks5Address)
        : connect({ hostname: addressRemote, port: portRemote });

      const tcpWriter = tcpSocket.writable.getWriter();
      await tcpWriter.write(new Uint8Array(rawClientData));
      tcpWriter.releaseLock();

      log(`connected to ${addressRemote}:${portRemote}`);

      // Pipe TCP response → xhttp download stream
      let firstChunk = true;
      tcpSocket.readable.pipeTo(new WritableStream({
        async write(chunk) {
          if (firstChunk) {
            // prepend VLESS response header on first chunk
            const data = concatBuffers(vlessResponseHeader, chunk);
            await sessionWriter.write(new Uint8Array(data));
            firstChunk = false;
          } else {
            await sessionWriter.write(new Uint8Array(
              chunk instanceof ArrayBuffer ? chunk : chunk.buffer ?? chunk
            ));
          }
        },
        close() {
          log(`TCP closed`);
          sessionWriter.close().catch(() => {});
          xhttpSessions.delete(sessionID);
        },
        abort(reason) {
          log(`TCP aborted: ${reason}`);
          sessionWriter.abort(reason).catch(() => {});
          xhttpSessions.delete(sessionID);
        },
      })).catch(e => {
        log(`TCP pipe error: ${e.message}`);
        sessionWriter.close().catch(() => {});
        xhttpSessions.delete(sessionID);
      });

    } catch (e) {
      log(`TCP connect error: ${e.message}`);
      // retry with proxyIP
      try {
        const tcpSocket = connect({
          hostname: config.proxyIP || addressRemote,
          port: config.proxyPort || portRemote,
        });
        const tcpWriter = tcpSocket.writable.getWriter();
        await tcpWriter.write(new Uint8Array(rawClientData));
        tcpWriter.releaseLock();
        let firstChunk = true;
        tcpSocket.readable.pipeTo(new WritableStream({
          async write(chunk) {
            if (firstChunk) {
              await sessionWriter.write(new Uint8Array(concatBuffers(vlessResponseHeader, chunk)));
              firstChunk = false;
            } else {
              await sessionWriter.write(new Uint8Array(chunk instanceof ArrayBuffer ? chunk : chunk.buffer ?? chunk));
            }
          },
          close() { sessionWriter.close().catch(() => {}); xhttpSessions.delete(sessionID); },
          abort() { sessionWriter.abort().catch(() => {}); xhttpSessions.delete(sessionID); },
        })).catch(() => { sessionWriter.close().catch(() => {}); });
      } catch (retryErr) {
        log(`Retry failed: ${retryErr.message}`);
        sessionWriter.close().catch(() => {});
      }
    }

    return new Response("ok", { status: 200 });
  }

  return new Response("Method not allowed", { status: 405 });
}

// Session map: sessionID → TransformStream writer
// Correlates GET (download) and POST (upload) for the same xhttp session
const xhttpSessions = new Map();


// ───────────────────────────────────────────────────────────────────────────
// Shared internals (used by both ws and xhttp handlers)
// ───────────────────────────────────────────────────────────────────────────

function isValidUUID(uuid) {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

async function HandleTCPOutBound(
  remoteSocket, addressType, addressRemote, portRemote,
  rawClientData, webSocket, protocolResponseHeader, log, config,
) {
  async function connectAndWrite(address, port, socks = false) {
    let tcpSocket;
    if (config.socks5Relay) {
      tcpSocket = await socks5Connect(addressType, address, port, log, config.parsedSocks5Address);
    } else {
      tcpSocket = socks
        ? await socks5Connect(addressType, address, port, log, config.parsedSocks5Address)
        : connect({ hostname: address, port: port });
    }
    remoteSocket.value = tcpSocket;
    log(`connected to ${address}:${port}`);
    const writer = tcpSocket.writable.getWriter();
    await writer.write(rawClientData);
    writer.releaseLock();
    return tcpSocket;
  }

  async function retry() {
    try {
      const tcpSocket = config.enableSocks
        ? await connectAndWrite(addressRemote, portRemote, true)
        : await connectAndWrite(config.proxyIP || addressRemote, config.proxyPort || portRemote, false);
      tcpSocket.closed
        .catch((error) => console.log("retry tcpSocket closed error", error))
        .finally(() => safeCloseWebSocket(webSocket));
      RemoteSocketToWS(tcpSocket, webSocket, protocolResponseHeader, null, log);
    } catch (error) {
      log(`[TCP-OUT] RETRY failed: ${error.message}`);
    }
  }

  try {
    const tcpSocket = await connectAndWrite(addressRemote, portRemote);
    RemoteSocketToWS(tcpSocket, webSocket, protocolResponseHeader, retry, log);
  } catch (error) {
    log(`[TCP-OUT] PRIMARY CONNECTION FAILED: ${error.message}`);
    await retry();
  }
}

function MakeReadableWebSocketStream(webSocketServer, earlyDataHeader, log) {
  return new ReadableStream({
    start(controller) {
      webSocketServer.addEventListener("message", (event) => {
        const data = event.data instanceof Blob ? event.data.arrayBuffer() : event.data;
        if (data instanceof Promise) {
          data.then(buffer => controller.enqueue(buffer)).catch(err => controller.error(err));
        } else {
          controller.enqueue(data);
        }
      });
      webSocketServer.addEventListener("close", () => {
        safeCloseWebSocket(webSocketServer);
        controller.close();
      });
      webSocketServer.addEventListener("error", (err) => {
        log("webSocketServer has error");
        controller.error(err);
      });
      const { earlyData, error } = base64ToArrayBuffer(earlyDataHeader);
      if (error) controller.error(error);
      else if (earlyData) controller.enqueue(earlyData);
    },
    cancel(reason) {
      log(`ReadableStream was canceled, due to ${reason}`);
      safeCloseWebSocket(webSocketServer);
    },
  });
}

function ProcessProtocolHeader(protocolBuffer, userID) {
  if (protocolBuffer.byteLength < 24) return { hasError: true, message: "invalid data" };
  const dataView = new DataView(protocolBuffer);
  const version = dataView.getUint8(0);
  const slicedBufferString = stringify(new Uint8Array(protocolBuffer.slice(1, 17)));
  const uuids = userID.split(",").map((id) => id.trim());
  if (!slicedBufferString) return { hasError: true, message: "invalid uuid format" };
  const isValidUser = uuids.some((uuid) => slicedBufferString === uuid);
  if (!isValidUser) return { hasError: true, message: "invalid user" };

  const optLength = dataView.getUint8(17);
  const command = dataView.getUint8(18 + optLength);
  if (command !== 1 && command !== 2)
    return { hasError: true, message: `command ${command} is not supported` };

  const portIndex = 18 + optLength + 1;
  const portRemote = dataView.getUint16(portIndex);
  const addressType = dataView.getUint8(portIndex + 2);
  let addressValue, addressLength, addressValueIndex;

  switch (addressType) {
    case 1:
      addressLength = 4;
      addressValueIndex = portIndex + 3;
      addressValue = new Uint8Array(protocolBuffer.slice(addressValueIndex, addressValueIndex + addressLength)).join(".");
      break;
    case 2:
      addressLength = dataView.getUint8(portIndex + 3);
      addressValueIndex = portIndex + 4;
      addressValue = sharedTextDecoder.decode(protocolBuffer.slice(addressValueIndex, addressValueIndex + addressLength));
      break;
    case 3:
      addressLength = 16;
      addressValueIndex = portIndex + 3;
      addressValue = Array.from({ length: 8 }, (_, i) =>
        dataView.getUint16(addressValueIndex + i * 2).toString(16),
      ).join(":");
      break;
    default:
      return { hasError: true, message: `invalid addressType: ${addressType}` };
  }

  if (!addressValue)
    return { hasError: true, message: `addressValue is empty, addressType is ${addressType}` };

  return {
    hasError: false,
    addressRemote: addressValue,
    addressType,
    portRemote,
    rawDataIndex: addressValueIndex + addressLength,
    ProtocolVersion: new Uint8Array([version]),
    isUDP: command === 2,
  };
}

async function RemoteSocketToWS(remoteSocket, webSocket, protocolResponseHeader, retry, log) {
  let hasIncomingData = false;
  try {
    await remoteSocket.readable.pipeTo(
      new WritableStream({
        async write(chunk) {
          if (webSocket.readyState !== CONST.WS_READY_STATE_OPEN)
            throw new Error("WebSocket is not open");
          hasIncomingData = true;
          const dataToSend = protocolResponseHeader
            ? concatBuffers(protocolResponseHeader, chunk)
            : chunk;
          webSocket.send(dataToSend);
          protocolResponseHeader = null;
        },
        close() { log(`Remote connection readable closed.`); },
        abort(reason) { console.error(`Remote connection readable aborted:`, reason); },
      }),
    );
  } catch (error) {
    console.error(`RemoteSocketToWS error:`, error.stack || error);
    safeCloseWebSocket(webSocket);
  }

  if (!hasIncomingData && retry) {
    log(`No incoming data, retrying`);
    await retry();
  }
}

function base64ToArrayBuffer(base64Str) {
  if (!base64Str) return { earlyData: null, error: null };
  try {
    const binaryStr = atob(base64Str.replace(/-/g, "+").replace(/_/g, "/"));
    const buffer = new ArrayBuffer(binaryStr.length);
    const view = new Uint8Array(buffer);
    for (let i = 0; i < binaryStr.length; i++) view[i] = binaryStr.charCodeAt(i);
    return { earlyData: buffer, error: null };
  } catch (error) {
    return { earlyData: null, error };
  }
}

function safeCloseWebSocket(socket) {
  try {
    if (socket.readyState === CONST.WS_READY_STATE_OPEN || socket.readyState === CONST.WS_READY_STATE_CLOSING)
      socket.close();
  } catch (error) {
    console.error("safeCloseWebSocket error:", error);
  }
}

const byteToHex = Array.from({ length: 256 }, (_, i) => (i + 0x100).toString(16).slice(1));

function unsafeStringify(arr, offset = 0) {
  return (
    byteToHex[arr[offset]] + byteToHex[arr[offset + 1]] +
    byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" +
    byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" +
    byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" +
    byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" +
    byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] +
    byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] +
    byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]
  ).toLowerCase();
}

function stringify(arr, offset = 0) {
  const uuid = unsafeStringify(arr, offset);
  return isValidUUID(uuid) ? uuid : "";
}

async function createDnsPipeline(webSocket, vlessResponseHeader, log) {
  let isHeaderSent = false;
  const transformStream = new TransformStream({
    transform(chunk, controller) {
      for (let index = 0; index < chunk.byteLength; ) {
        const lengthBuffer = chunk.slice(index, index + 2);
        const udpPacketLength = new DataView(lengthBuffer).getUint16(0);
        const udpData = new Uint8Array(chunk.slice(index + 2, index + 2 + udpPacketLength));
        index = index + 2 + udpPacketLength;
        controller.enqueue(udpData);
      }
    },
  });

  transformStream.readable.pipeTo(new WritableStream({
    async write(chunk) {
      try {
        const resp = await safeFetch(
          `https://1.1.1.1/dns-query`,
          { method: "POST", headers: { "content-type": "application/dns-message" }, body: chunk },
          3000,
        );
        const dnsQueryResult = await resp.arrayBuffer();
        const udpSize = dnsQueryResult.byteLength;
        const udpSizeBuffer = new Uint8Array([(udpSize >> 8) & 0xff, udpSize & 0xff]);
        if (webSocket.readyState === CONST.WS_READY_STATE_OPEN) {
          if (isHeaderSent) {
            webSocket.send(concatBuffers(udpSizeBuffer, dnsQueryResult));
          } else {
            webSocket.send(concatBuffers(vlessResponseHeader, udpSizeBuffer, dnsQueryResult));
            isHeaderSent = true;
          }
        }
      } catch (error) {
        log("DNS query error: " + error);
      }
    },
  })).catch((e) => log("DNS stream error: " + e));

  const writer = transformStream.writable.getWriter();
  return { write: (chunk) => writer.write(chunk) };
}

async function socks5Connect(addressType, addressRemote, portRemote, log, parsedSocks5Addr) {
  const { username, password, hostname, port } = parsedSocks5Addr;
  const socket = connect({ hostname, port });
  const writer = socket.writable.getWriter();
  const reader = socket.readable.getReader();
  const encoder = new TextEncoder();

  await writer.write(new Uint8Array([5, 2, 0, 2]));
  let res = (await reader.read()).value;
  if (res[0] !== 0x05 || res[1] === 0xff) throw new Error("SOCKS5 server connection failed.");

  if (res[1] === 0x02) {
    if (!username || !password) throw new Error("SOCKS5 auth credentials not provided.");
    const authRequest = new Uint8Array([1, username.length, ...encoder.encode(username), password.length, ...encoder.encode(password)]);
    await writer.write(authRequest);
    res = (await reader.read()).value;
    if (res[0] !== 0x01 || res[1] !== 0x00) throw new Error("SOCKS5 authentication failed.");
  }

  let DSTADDR;
  switch (addressType) {
    case 1: DSTADDR = new Uint8Array([1, ...addressRemote.split(".").map(Number)]); break;
    case 2: DSTADDR = new Uint8Array([3, addressRemote.length, ...encoder.encode(addressRemote)]); break;
    case 3: DSTADDR = new Uint8Array([4, ...addressRemote.split(":").flatMap((x) => [parseInt(x.slice(0, 2), 16), parseInt(x.slice(2), 16)])]); break;
    default: throw new Error(`Invalid addressType for SOCKS5: ${addressType}`);
  }

  const socksRequest = new Uint8Array([5, 1, 0, ...DSTADDR, portRemote >> 8, portRemote & 0xff]);
  await writer.write(socksRequest);
  res = (await reader.read()).value;
  if (res[1] !== 0x00) throw new Error("Failed to open SOCKS5 connection.");

  writer.releaseLock();
  reader.releaseLock();
  return socket;
}
